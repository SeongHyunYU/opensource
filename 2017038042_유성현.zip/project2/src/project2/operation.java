package project2;
import java.util.Scanner;
public class operation {
public static void main(String[] args) {
	System.out.print("���� :");
	Scanner s = new Scanner(System.in);
	int operation1 = s.nextInt();
	String operation = s.next();
	int operation2 = s.nextInt();
	
	int res = 0;
	if(operation.equals("+"))
		res=operation1+operation2;
	else if(operation.equals("-"))
		res=operation1-operation2;
	else if(operation.equals("*"))
		res=operation1*operation2;
	else if(operation.equals("/"))
		if(operation2==0) {
			System.out.print("0���� ���� �� �����ϴ�.");
			s.close();
			return;
			
			
		}
		else {
			res=operation1/operation2;
}
else {
	System.out.print("��Ģ������ �ƴմϴ�.");
	s.close();
	return;
}
	System.out.println(operation1+operation+operation2+"�� �������"+res);
	s.close();
    }
}
